﻿using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string[] validChannels = { "BE", "FE", "QA", "Urgent" };

        while (true)
        {
            Console.WriteLine("Enter the notification title:");
            string input = Console.ReadLine();

            string pattern = @"\[([A-Za-z]+)\]";
            MatchCollection matches = Regex.Matches(input, pattern);

            var channels = matches
                .Cast<Match>()
                .Select(match => match.Groups[1].Value)
                .Where(channel => validChannels.Contains(channel))
                .Distinct()
                .ToList();

            if (channels.Count > 0)
            {
                Console.WriteLine($"Received channels: {string.Join(", ", channels)}");
            }
            else
            {
                Console.WriteLine("No valid channels found in the input.");
            }

            while (true)
            {
                Console.WriteLine("Do you want to parse another title? (y/n)");
                string continueChoice = Console.ReadLine().ToLower();
                if (continueChoice == "y")
                {
                    break;
                }
                else if (continueChoice == "n")
                {
                    return;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'y' for continue or 'n' for not.");
                }
            }
        }
    }
}
